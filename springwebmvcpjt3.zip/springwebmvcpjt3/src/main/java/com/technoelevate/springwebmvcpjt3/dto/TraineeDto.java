package com.technoelevate.springwebmvcpjt3.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="trainee_details")
public class TraineeDto implements Serializable{
	@Id
	@Column(name="trn_id")
	private int tid;
	@Column(name="trn_name")
	private String tname;
	@Column(name="trn_pass")
	private String pwd;
	@Column(name="trn_phNum")
	private long phnum;
}
