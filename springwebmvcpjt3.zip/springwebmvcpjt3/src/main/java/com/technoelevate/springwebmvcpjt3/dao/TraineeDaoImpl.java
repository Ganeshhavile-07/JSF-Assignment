package com.technoelevate.springwebmvcpjt3.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.technoelevate.springwebmvcpjt3.dto.TraineeDto;

@Repository
public class TraineeDaoImpl implements TraineeDao {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public boolean addData(TraineeDto dto) {
		boolean isAdded = false;
		try {
			factory = Persistence.createEntityManagerFactory("hibernate3");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(dto);
			transaction.commit();
			isAdded = true;
			return isAdded;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			factory.close();
			manager.close();
		}
		return isAdded;
	}

	@Override
	public TraineeDto authenticate(int tid, String password) {
		try {
			factory = Persistence.createEntityManagerFactory("hibernate3");
			manager = factory.createEntityManager();
			TraineeDto dto = manager.find(TraineeDto.class, tid);
			if (dto.getPwd().equals(password)) {
				return dto;
			}
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			factory.close();
			manager.close();
		}
		return null;
	}

	@Override
	public boolean updateData(int tid) {
		boolean isUpdated = false;
		try {
			factory = Persistence.createEntityManagerFactory("hibernate3");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			TraineeDto dto = manager.find(TraineeDto.class, tid);
//			dto.setTname("--");
			dto.setPwd("ram@123");
//			dto.setPhnum(1l);
			transaction.commit();
			isUpdated = true;
			return isUpdated;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			factory.close();
			manager.close();
		}
		return isUpdated;
	}

	@Override
	public TraineeDto getData(int tid) {
		factory = Persistence.createEntityManagerFactory("hibernate3");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		TraineeDto dto = manager.find(TraineeDto.class, tid);
		return dto;
	}

	@Override
	public boolean deleteData(int tid) {
		factory = Persistence.createEntityManagerFactory("hibernate3");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		TraineeDto dto = manager.find(TraineeDto.class, tid);
		manager.remove(dto);
		transaction.commit();
		return true;
	}

}
