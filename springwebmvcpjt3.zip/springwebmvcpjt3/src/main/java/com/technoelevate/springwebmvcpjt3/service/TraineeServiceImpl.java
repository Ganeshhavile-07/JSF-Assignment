package com.technoelevate.springwebmvcpjt3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.springwebmvcpjt3.dao.TraineeDao;
import com.technoelevate.springwebmvcpjt3.dto.TraineeDto;

@Service
public class TraineeServiceImpl implements TraineeService {
	
	@Autowired
	TraineeDao dao;
	
	@Override
	public boolean addData(TraineeDto dto) {
		if(dto==null)
			return false;
		else
		return dao.addData(dto);
	}

	@Override
	public TraineeDto authenticate(int tid, String password) {
		
		return dao.authenticate(tid,password);
	}

	@Override
	public boolean updateData(int tid) {
		if (tid<=0) {
			return false;
		}else
		return dao.updateData(tid);
	}

	@Override
	public TraineeDto getData(int tid) {
		if (tid<=0) {
			return null;
		}
		return dao.getData(tid);
	}

	@Override
	public boolean deleteData(int tid) {
		if (tid>=0) {
			return dao.deleteData(tid);
		}
		return false;
	}

	

}
