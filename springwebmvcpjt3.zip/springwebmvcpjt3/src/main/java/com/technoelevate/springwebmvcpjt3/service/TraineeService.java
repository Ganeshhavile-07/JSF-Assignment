package com.technoelevate.springwebmvcpjt3.service;

import com.technoelevate.springwebmvcpjt3.dto.TraineeDto;

public interface TraineeService {
	public boolean addData(TraineeDto dto);

	public TraineeDto authenticate(int tid, String password); 
	
	public boolean updateData(int tid); 
		
	public TraineeDto getData(int tid);
	
	public boolean deleteData(int tid);
}
