package com.technoelevate.springwebmvcpjt3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.technoelevate.springwebmvcpjt3.dto.TraineeDto;
import com.technoelevate.springwebmvcpjt3.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService service;
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login")
	public String authenticate(ModelMap map,int tid,String password) {
		if (tid!=0) {
		TraineeDto dto = service.authenticate(tid,password);
		if (dto!=null) {
			String msg="Login Successful";
			map.addAttribute("key", msg);
		}else {
			String msg="Invalid User!!!";
			map.addAttribute("key", msg);
		}
		}
		return "loginData";
	}
	
	@GetMapping("/insert")
	public String addData() {
		return "insert";
	}
	
	@PostMapping("/insert")
	public String addData(ModelMap map, TraineeDto dto) {
		boolean result=service.addData(dto);
		if (result==true) {
			String msg="Data added successfully";
			map.addAttribute("msgKey", msg);
		}else {
			String msg="Data not inserted";
			map.addAttribute("msgKey", msg);
		}
		return "insertStatus";
	}
	
	@GetMapping("/update")
	public String updateData() {
		return "update";
	}
	
	@PostMapping("/update")
	public String updateData(ModelMap map,int tid) {
		boolean result=service.updateData(tid);
		if (result==true) {
			String msg="Data updated successfully";
			map.addAttribute("msgKey", msg);
		}else {
			String msg="Something went wrong!!!";
			map.addAttribute("msgKey", msg);
		}
		return "insertStatus";
	}
	
	@GetMapping("/search")
	public String getData() {
		return "find";
	}
	
	@PostMapping("/search")
	public String getData(ModelMap map,int tid) {
		TraineeDto dto = service.getData(tid);
		map.addAttribute("triKey", dto);
		return "display";
		
	}
	@GetMapping("/delete")
	public String deleteData() {
		return "delete";
	}
	
	@PostMapping("/delete")
	public String deleteData(ModelMap map,int tid) {
		boolean result=service.deleteData(tid);
		if (result==true) {
			String msg="Data deleted Successfully";
			map.addAttribute("msgKey", msg);
		}else {
			String msg="Something went wrong!!!!!";
			map.addAttribute("msgKey", msg);
		}
		return "insertStatus";
	}
}