package com.javatpoint.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.javatpoint.model.Student;

//@Repository means it is directly connected to the database
@Repository

public interface StudentRepository extends CrudRepository<Student, Integer> {
}
