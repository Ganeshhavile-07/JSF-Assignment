package com.capgemini.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
